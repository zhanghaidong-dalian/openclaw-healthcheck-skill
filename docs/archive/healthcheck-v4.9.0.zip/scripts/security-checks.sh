#!/bin/bash
# Security Check Functions - 安全检查函数库
# 版本: 4.0.0
# 用途: 提供通用的安全检查函数

# 检查文件权限
check_file_permissions() {
    local file_path="$1"
    local expected_mode="$2"  # 如 600, 640, 644
    local description="$3"

    if [ ! -f "$file_path" ]; then
        echo "⚠️  文件不存在: $file_path"
        return 1
    fi

    local actual_mode=$(stat -c "%a" "$file_path" 2>/dev/null || stat -f "%OLp" "$file_path" 2>/dev/null)

    if [ "$actual_mode" != "$expected_mode" ]; then
        echo "⚠️  $description 权限不安全: $actual_mode (期望: $expected_mode)"
        echo "   建议: chmod $expected_mode $file_path"
        return 1
    fi

    echo "✅ $description 权限安全: $actual_mode"
    return 0
}

# 检查目录权限
check_dir_permissions() {
    local dir_path="$1"
    local expected_mode="$2"  # 如 700, 750, 755
    local description="$3"

    if [ ! -d "$dir_path" ]; then
        echo "⚠️  目录不存在: $dir_path"
        return 1
    fi

    local actual_mode=$(stat -c "%a" "$dir_path" 2>/dev/null || stat -f "%OLp" "$dir_path" 2>/dev/null)

    if [ "$actual_mode" != "$expected_mode" ]; then
        echo "⚠️  $description 权限不安全: $actual_mode (期望: $expected_mode)"
        echo "   建议: chmod $expected_mode $dir_path"
        return 1
    fi

    echo "✅ $description 权限安全: $actual_mode"
    return 0
}

# 验证路径安全性
validate_path() {
    local path="$1"
    local allow_absolute="${2:-false}"

    # 检查路径遍历
    if [[ "$path" =~ \.\. ]]; then
        echo "❌ 错误: 路径包含..（路径遍历风险）"
        return 1
    fi

    # 检查绝对路径
    if [ "$allow_absolute" != "true" ] && [[ "$path" =~ ^/ ]]; then
        echo "❌ 错误: 不允许使用绝对路径"
        return 1
    fi

    # 检查特殊字符
    if [[ "$path" =~ [<>\"'\\] ]]; then
        echo "❌ 错误: 路径包含特殊字符"
        return 1
    fi

    return 0
}

# 检查命令可用性
check_command() {
    local cmd="$1"
    local optional="${2:-false}"

    if ! command -v "$cmd" &>/dev/null; then
        if [ "$optional" != "true" ]; then
            echo "❌ 错误: 命令不存在: $cmd"
            return 1
        else
            echo "⚠️  警告: 命令不存在: $cmd（可选）"
            return 0
        fi
    fi

    return 0
}

# 安全的文件写入（原子操作）
safe_write() {
    local file_path="$1"
    local content="$2"
    local description="${3:-文件}"

    # 验证路径
    local dir_path=$(dirname "$file_path")
    mkdir -p "$dir_path"

    # 使用临时文件进行原子写入
    local temp_file="${file_path}.$$"

    # 写入临时文件
    echo "$content" > "$temp_file"
    if [ $? -ne 0 ]; then
        echo "❌ 错误: 无法写入临时文件: $temp_file"
        rm -f "$temp_file"
        return 1
    fi

    # 原子重命名
    mv "$temp_file" "$file_path"
    if [ $? -ne 0 ]; then
        echo "❌ 错误: 无法移动文件到目标位置: $file_path"
        rm -f "$temp_file"
        return 1
    fi

    echo "✅ $description 已安全写入: $file_path"
    return 0
}

# 导出函数
export -f check_file_permissions
export -f check_dir_permissions
export -f validate_path
export -f check_command
export -f safe_write
