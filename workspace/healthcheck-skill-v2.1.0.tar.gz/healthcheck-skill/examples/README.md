# 使用示例 | Usage Examples

## 示例1：完整安全检查

```bash
# 执行完整的安全检查（推荐）
$ healthcheck --deep

🔍 环境检测中...
[✓] Root 权限检查
[✓] 容器检测
[✓] 沙盒检测
[✓] 云服务商检测
[✓] 网络检查
[✓] SSH 状态

🔄 综合安全审计进行中 [步骤 2/8]
[████████████████░░░░] 80%

📊 安全审计报告
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
环境类型: VPS/阿里云
风险等级: 🔴 高危

🔴 Critical (3):
  1. CVE-2026-25253: ClawJacked漏洞
  2. CVE-2026-28466: Node审批绕过
  3. malicious_skill: youtube-summarize-pro

🟠 High (2):
  1. credential_plaintext_storage
  2. insecure_mcp_permissions

修复建议:
  1. 运行: openclaw security audit --fix --severity=critical
  2. 升级: openclaw update
  3. 删除: openclaw skills remove youtube-summarize-pro
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## 示例2：CVE专项检查

```bash
# 仅检查CVE漏洞
$ healthcheck --cve-check

🔴 CVE 专项安全报告
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
检查时间: 2026-03-27 10:30 CST
OpenClaw版本: 2026.3.8 (需要升级)

【在野利用漏洞 - 立即修复】
❌ CVE-2026-25253 (ClawJacked) CVSS 8.8
   风险: 一键远程代码执行
   状态: 配置存在漏洞
   修复: 自动修复可用 ✅
   
   检查项:
     ❌ gateway.controlUi.allowCustomGatewayUrl = true (应为false)
     ❌ gateway.websocket.verifyOrigin = false (应为true)
     ❌ gateway.devicePairing.requireConfirmation = false (应为true)
     ❌ gateway.rateLimit.localhostExempt = true (应为false)
   
   修复命令:
     $ openclaw config set gateway.controlUi.allowCustomGatewayUrl false
     $ openclaw config set gateway.websocket.verifyOrigin true
     $ openclaw config set gateway.devicePairing.requireConfirmation true
     $ openclaw config set gateway.rateLimit.localhostExempt false

❌ CVE-2026-28466 (Node审批绕过) CVSS 9.4
   风险: 绕过执行审批
   状态: 版本存在漏洞 (<2026.3.12)
   修复: 需手动升级 ⚠️
   
   升级命令:
     $ openclaw update

【已修复/安全】
✅ CVE-2026-32302 - 配置安全
✅ CVE-2026-29610 - PATH安全

【一键修复所有配置漏洞】
$ openclaw security audit --fix --severity=critical
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## 示例3：恶意技能扫描

```bash
# 扫描已安装技能
$ healthcheck --skill-scan

🦠 技能供应链安全报告
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
扫描技能总数: 15
官方技能: 12
第三方技能: 3

🔴 发现恶意技能 (1):
   youtube-summarize-pro
   ├─ 风险: 植入Atomic Stealer木马
   ├─ 来源: ClawHavoc攻击活动
   ├─ 攻击手法: 诱导执行curl|bash命令
   └─ 操作: 建议立即删除
   
   删除命令:
     $ openclaw skills remove youtube-summarize-pro
     $ rm -rf ~/.openclaw/skills/youtube-summarize-pro

⚠️  发现可疑技能 (2):
   custom-tool-1:
     ├─ 风险: 包含外部下载链接
     └─ 建议: 人工审查代码
     
   custom-tool-2:
     ├─ 风险: 请求过高权限
     └─ 建议: 检查权限配置

✅ 安全技能 (12):
   所有官方技能已通过验证

【安全建议】
1. 立即删除恶意技能
2. 审查可疑技能代码
3. 仅从官方ClawHub安装技能
4. 启用技能自动更新检查

【已知恶意技能黑名单】
- solana-wallet-tracker (窃取加密货币)
- youtube-summarize-pro (植入木马)
- polymarket-trader (窃取交易凭证)
- bybit-trading (恶意代码)
- linkedin-job-application (AuthTool木马)
- 共1,184个已知恶意技能...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## 示例4：一键修复

```bash
# 一键修复所有Critical级别问题
$ healthcheck --fix --severity=critical

🚨 即将修复以下 Critical 级别问题:

1. CVE-2026-25253 (ClawJacked漏洞)
   - 设置 gateway.controlUi.allowCustomGatewayUrl = false
   - 设置 gateway.websocket.verifyOrigin = true
   - 设置 gateway.devicePairing.requireConfirmation = true
   - 设置 gateway.rateLimit.localhostExempt = false

2. device_auth_disabled
   - 启用设备认证

3. file_permission_issues
   - 修复 ~/.openclaw/config.json 权限为 600

确认修复? (yes/no): yes

🔄 修复中...
[████████████████████] 100%

✅ 修复完成:
  - CVE-2026-25253 配置已修复
  - 设备认证已启用
  - 文件权限已修复

⚠️ 需要手动处理:
  - CVE-2026-28466: 请运行 `openclaw update` 升级版本

建议重启OpenClaw服务以应用所有更改:
  $ openclaw restart
```

## 示例5：生成不同格式的报告

```bash
# Markdown格式报告（适合存档）
$ healthcheck --deep --format=markdown > security-report.md

# JSON格式报告（适合程序处理）
$ healthcheck --deep --format=json > security-report.json

# 对比报告（显示修复前后变化）
$ healthcheck --deep --format=compare

📊 安全状态对比
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
修复前              修复后
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔴 Critical: 4    →    Critical: 1  ✅
🟠 High: 6        →    High: 2      ✅
🟡 Medium: 8      →    Medium: 8    ➖
🟢 Low: 3         →    Low: 3       ➖
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
安全评分：35/100  →  82/100  ⬆️ +47%
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## 示例6：定时任务设置

```bash
# 设置每周自动安全检查
$ openclaw cron add \
  --name healthcheck:security-audit \
  --schedule "0 9 * * 1" \
  --command "healthcheck --deep"

✅ 定时任务已创建
名称: healthcheck:security-audit
执行时间: 每周一 09:00
命令: healthcheck --deep

# 查看定时任务
$ openclaw cron list

# 立即执行一次检查
$ openclaw cron run healthcheck:security-audit
```

## 示例7：新部署VPS初始化

```bash
# 场景：刚购买的阿里云VPS，需要部署OpenClaw

# 1. 安装OpenClaw
$ curl -fsSL https://openclaw.ai/install.sh | bash

# 2. 立即运行安全检查
$ healthcheck --deep

🔍 环境检测: VPS/阿里云
⚠️  发现高危配置问题:
   - 端口18789暴露到公网
   - 未启用身份认证
   - 发现2个CVE配置漏洞

# 3. 一键修复
$ healthcheck --fix --severity=critical

# 4. 加固配置
$ openclaw config set gateway.bind "127.0.0.1"
$ openclaw config set gateway.auth.mode "token"
$ openclaw config set gateway.auth.token "$(openssl rand -hex 32)"

# 5. 配置防火墙
$ sudo ufw default deny incoming
$ sudo ufw allow from 192.168.1.0/24 to any port 18789
$ sudo ufw enable

# 6. 再次检查
$ healthcheck --deep
✅ 所有Critical问题已修复
✅ 风险等级: 低
```

## 示例8：发现恶意技能后的应急处理

```bash
# 场景：怀疑安装了恶意技能

# 1. 立即停止OpenClaw
$ openclaw stop

# 2. 运行技能安全扫描
$ healthcheck --skill-scan

🚨 发现恶意技能: youtube-summarize-pro
   风险: 植入Atomic Stealer木马

# 3. 删除恶意技能
$ openclaw skills remove youtube-summarize-pro
$ rm -rf ~/.openclaw/skills/youtube-summarize-pro

# 4. 检查系统异常
$ ps aux | grep -E "atomic|stealer|suspicious"
$ netstat -tlnp | grep -E "4444|5555|6666"

# 5. 重置所有凭证
$ openclaw credentials reset --all
$ openclaw config set gateway.auth.token "$(openssl rand -hex 32)"

# 6. 更新所有API密钥
# - 登录各云平台更换API密钥
# - 更新OpenClaw配置文件

# 7. 完整安全扫描
$ healthcheck --deep

# 8. 重新启动OpenClaw
$ openclaw start

# 9. 监控异常行为
$ tail -f ~/.openclaw/logs/security-audit/audit.log
```

## 示例9：企业级安全加固

```bash
# 场景：企业环境部署OpenClaw

# 1. 创建专用低权限用户
$ sudo useradd -r -s /bin/false openclaw_user
$ sudo mkdir -p /opt/openclaw
$ sudo chown openclaw_user:openclaw_user /opt/openclaw

# 2. 安装OpenClaw
$ sudo -u openclaw_user bash -c "curl -fsSL https://openclaw.ai/install.sh | bash"

# 3. 运行全面安全检查
$ sudo -u openclaw_user healthcheck --deep

# 4. 配置最小权限
$ sudo -u openclaw_user openclaw config set tools.exec.enabled false
$ sudo -u openclaw_user openclaw config set tools.denylist '["system.run", "process.kill"]'

# 5. 设置审计日志
$ sudo mkdir -p /var/log/openclaw
$ sudo chown openclaw_user:openclaw_user /var/log/openclaw
$ sudo -u openclaw_user openclaw config set logging.audit.enabled true
$ sudo -u openclaw_user openclaw config set logging.audit.path "/var/log/openclaw"

# 6. 设置定时安全审计
$ sudo -u openclaw_user openclaw cron add \
  --name healthcheck:enterprise-audit \
  --schedule "0 */6 * * *" \
  --command "healthcheck --deep --format=json > /var/log/openclaw/audit-$(date +%Y%m%d-%H%M).json"

# 7. 集成SIEM（示例：Splunk）
$ sudo -u openclaw_user openclaw config set logging.forward.enabled true
$ sudo -u openclaw_user openclaw config set logging.forward.endpoint "https://splunk.company.com:8088"

# 8. 最终验证
$ sudo -u openclaw_user healthcheck --deep
✅ 企业级安全配置完成
```

## 示例10：CI/CD集成

```yaml
# .github/workflows/security-audit.yml
name: OpenClaw Security Audit

on:
  schedule:
    - cron: '0 2 * * *'  # 每天凌晨2点
  push:
    branches: [main]

jobs:
  security-audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install OpenClaw
        run: |
          curl -fsSL https://openclaw.ai/install.sh | bash
      
      - name: Run Security Audit
        run: |
          healthcheck --deep --format=json > audit-report.json
      
      - name: Check for Critical Issues
        run: |
          CRITICAL_COUNT=$(jq '.findings.critical' audit-report.json)
          if [ "$CRITICAL_COUNT" -gt 0 ]; then
            echo "🚨 Found $CRITICAL_COUNT critical security issues!"
            jq '.cve_check | to_entries[] | select(.value.status == "vulnerable")' audit-report.json
            exit 1
          fi
      
      - name: Upload Report
        uses: actions/upload-artifact@v3
        with:
          name: security-audit-report
          path: audit-report.json
```

