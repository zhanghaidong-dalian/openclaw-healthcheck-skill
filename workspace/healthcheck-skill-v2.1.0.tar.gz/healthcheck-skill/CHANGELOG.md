# 发布说明 | Release Notes

## v2.1.0 (2026-03-27) - 安全紧急更新 🔴

### 🚨 重要更新

本次更新集成了**2026年3月最新威胁情报**，新增对12个已发现在野利用的CVE漏洞的专项检测，以及1,184个已知恶意技能的数据库。

### 🔴 新增：CVE专项安全检查

#### 覆盖的CVE漏洞

| CVE编号 | CVSS | 风险等级 | 在野利用 | 修复方式 |
|---------|------|---------|---------|---------|
| CVE-2026-25253 | 8.8 | Critical | ✅ | 配置修复 |
| CVE-2026-32302 | 8.1 | Critical | ⚠️ | 配置修复 |
| CVE-2026-28466 | 9.4 | Critical | ✅ | 升级版本 |
| CVE-2026-29610 | 8.8 | Critical | ✅ | 配置修复 |
| CVE-2026-24763 | 8.8 | High | ⚠️ | 升级版本 |
| CVE-2026-25157 | 8.1 | High | ⚠️ | 升级版本 |
| CVE-2026-27001 | - | Medium | ⚠️ | 配置修复 |
| CVE-2026-25475 | 6.5 | Medium | ✅ | 配置修复 |
| CVE-2026-26322 | 8.8 | High | ⚠️ | 配置修复 |
| CVE-2026-26329 | 7.5 | High | ⚠️ | 配置修复 |
| CVE-2026-25593 | 7.5 | Medium | ⚠️ | 配置修复 |

#### CVE-2026-25253 (ClawJacked) 专项

**漏洞描述**：攻击者通过恶意链接实现一键远程代码执行，完全接管OpenClaw

**检测内容**：
- gateway.controlUi.allowCustomGatewayUrl
- gateway.websocket.verifyOrigin
- gateway.devicePairing.requireConfirmation
- gateway.rateLimit.localhostExempt

**一键修复命令**：
```bash
openclaw config set gateway.controlUi.allowCustomGatewayUrl false
openclaw config set gateway.websocket.verifyOrigin true
openclaw config set gateway.devicePairing.requireConfirmation true
openclaw config set gateway.rateLimit.localhostExempt false
```

### 🦠 新增：恶意技能/插件供应链安全检查

#### 恶意技能数据库

集成 **1,184个已知恶意技能**，包括：

**ClawHavoc攻击活动**（335个恶意技能）：
- solana-wallet-tracker - 窃取加密货币钱包
- youtube-summarize-pro - 植入Atomic Stealer木马
- polymarket-trader - 窃取交易凭证
- youtube-video-downloader - 窃取浏览器数据

**GitHub投毒**：
- bybit-trading - 恶意代码执行
- linkedin-job-application - AuthTool木马

#### 自动扫描功能

- 扫描已安装技能列表
- 匹配恶意技能数据库
- 检查可疑代码模式：
  - `curl ... | bash` 危险模式
  - `base64` 混淆执行
  - `nc -e` 反向shell
  - 外部下载链接

### 💉 新增：提示词注入防护检查

- 输入过滤配置检测
- HTML注释过滤检测
- 隐藏内容检测
- 系统指令保护检测

### 🛠️ 新增：MCP工具权限审计

- exec工具配置检查
- browser工具配置检查
- web_fetch工具配置检查
- 高危工具白名单/黑名单检查

### 🔐 新增：敏感数据保护检查

- 明文API密钥扫描
- SSH密钥权限检查
- OpenClaw配置文件权限
- MEMORY.md敏感信息检测

### 📊 增强：报告系统

新增2种报告格式：
- **CVE专项报告** - 详细漏洞检测和修复建议
- **技能安全报告** - 供应链安全分析

### 📚 扩展：FAQ

新增8个CVE和恶意技能专项FAQ：
1. CVE-2026-25253有多危险？
2. 如何修复CVE-2026-25253？
3. 如何识别恶意技能？
4. 发现恶意技能怎么办？
5. 提示词注入攻击是什么？
6. 公网暴露怎么办？
7. CVE-2026-28466能自动修复吗？
8. 为什么需要检查PATH环境变量？

### 📈 文档规模

- 文档行数：837行 → **1,477行** (+76%)
- 安全检查项：8项 → **20+项**
- CVE覆盖：0个 → **12个**
- 恶意技能库：0个 → **1,184个**

### ⚡ 性能优化

- 优化检测脚本执行效率
- 新增进度显示机制
- 改进错误处理策略

### 🐛 Bug修复

- 修复沙盒环境误报问题
- 优化环境检测准确性

---

## v2.0.0 (2026-03-27)

### ✨ 新增功能

- 环境自动检测（支持5种环境类型）
- 分级修复体系（Tier 1/2/3）
- 进度追踪机制
- 一键快速修复模式
- 多格式报告输出（文本/Markdown/JSON/对比）
- 云服务商识别（阿里云、腾讯云、AWS等）
- 错误处理和回滚机制
- 中文全面支持
- 技能集成接口

### 📚 文档

- 详细的使用场景示例
- 常见问题解答
- 环境参考指南

---

## v1.0.0 (2026-01-15)

### 🎉 初始发布

- 基础安全审计功能
- 定时任务支持
- 文件权限修复

---

## 升级指南

### 从 v2.0.0 升级到 v2.1.0

```bash
# 更新技能
openclaw skills update healthcheck

# 运行新的CVE专项检查
healthcheck --cve-check

# 扫描恶意技能
healthcheck --skill-scan
```

### 从 v1.0.0 升级到 v2.1.0

```bash
# 重新安装
openclaw skills remove healthcheck
openclaw skills install healthcheck

# 运行全面检查
healthcheck --deep
```

---

## 已知问题

- CVE-2026-28466等漏洞需要升级OpenClaw版本才能完全修复
- 部分恶意技能可能需要手动清除

---

## 下一步计划

### v2.2.0 (计划中)

- [ ] 集成更多CVE漏洞检测
- [ ] 自动更新恶意技能数据库
- [ ] 添加实时监控功能
- [ ] 支持更多云平台

### v3.0.0 (规划中)

- [ ] AI驱动的异常检测
- [ ] 自动威胁响应
- [ ] 企业级安全仪表盘

---

**建议所有用户立即升级到v2.1.0！**

